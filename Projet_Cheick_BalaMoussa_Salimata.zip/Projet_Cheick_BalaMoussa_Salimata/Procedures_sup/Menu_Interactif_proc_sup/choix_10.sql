SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT =========================================
PROMPT |         EMPRUNTS EN COURS             |
PROMPT =========================================
PROMPT

BEGIN
    AfficherEmpruntsEnCours;
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql