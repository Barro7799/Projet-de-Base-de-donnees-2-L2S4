SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT =========================================
PROMPT |       LISTE DE TOUS LES ABONNES       |
PROMPT =========================================
PROMPT

BEGIN
    AfficherTousAbonnes;
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql