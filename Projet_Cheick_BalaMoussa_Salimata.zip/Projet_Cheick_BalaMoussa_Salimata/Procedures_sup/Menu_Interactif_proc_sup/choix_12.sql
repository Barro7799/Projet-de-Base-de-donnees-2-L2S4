SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE mot_cle
UNDEFINE type_recherche

PROMPT =========================================
PROMPT |        RECHERCHER UN LIVRE            |
PROMPT =========================================
PROMPT |  Recherche par : TITRE  ou  AUTEUR    |
PROMPT =========================================
ACCEPT type_recherche PROMPT 'Type de recherche (TITRE/AUTEUR) : '
ACCEPT mot_cle        PROMPT 'Mot cle a rechercher             : '
PROMPT

BEGIN
    RechercherLivre('&&mot_cle', '&&type_recherche');
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql