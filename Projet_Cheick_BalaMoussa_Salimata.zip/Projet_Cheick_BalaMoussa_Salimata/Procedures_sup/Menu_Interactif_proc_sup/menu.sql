
-- ============================================================
-- MENU PRINCIPAL (fichier: menu.sql)
-- ============================================================
SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT
PROMPT ==========================================
PROMPT |  BIENVENUE DANS LE SYSTEME DE GESTION  |
PROMPT |         DE LA BIBLIOTHEQUE             |
PROMPT ==========================================
PROMPT |           MENU PRINCIPAL               |
PROMPT ==========================================
PROMPT |  1.  Ajouter un livre                  |
PROMPT |  2.  Ajouter un abonne                 |
PROMPT |  3.  Emprunter un livre                |
PROMPT |  4.  Retourner un livre                |
PROMPT |  5.  Afficher les livres disponibles   |
PROMPT |  6.  Supprimer un livre                |
PROMPT |  7.  Desabonner un abonne              |
PROMPT |  8.  Modifier les informations         |
PROMPT |  9.  Afficher tous les abonnes         |
PROMPT |  10. Afficher les emprunts en cours    |
PROMPT |  11. Historique emprunts d un abonne   |
PROMPT |  12. Rechercher un livre               |
PROMPT |  13. Quitter                           |
PROMPT ==========================================
PROMPT

ACCEPT v_choix PROMPT 'Bienvenue!! Quelle operation souhaitez-vous effectuer (1-6) : '

COLUMN nom_fichier NEW_VALUE fichier_a_executer NOPRINT

SELECT CASE
    WHEN &v_choix = 1  THEN 'choix_1.sql'
    WHEN &v_choix = 2  THEN 'choix_2.sql'
    WHEN &v_choix = 3  THEN 'choix_3.sql'
    WHEN &v_choix = 4  THEN 'choix_4.sql'
    WHEN &v_choix = 5  THEN 'choix_5.sql'
    WHEN &v_choix = 6  THEN 'choix_6.sql'
    WHEN &v_choix = 7  THEN 'choix_7.sql'
    WHEN &v_choix = 8  THEN 'choix_8.sql'
    WHEN &v_choix = 9  THEN 'choix_9.sql'
    WHEN &v_choix = 10 THEN 'choix_10.sql'
    WHEN &v_choix = 11 THEN 'choix_11.sql'
    WHEN &v_choix = 12 THEN 'choix_12.sql'
    WHEN &v_choix = 13 THEN 'choix_13.sql'
    ELSE 'choix.sql'
END AS nom_fichier
FROM DUAL;

-- Exécuter le fichier correspondant
@Procedures_sup\Menu_Interactif_proc_sup\&fichier_a_executer