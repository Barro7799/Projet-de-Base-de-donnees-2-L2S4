SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_livre

PROMPT =========================================
PROMPT |        SUPPRIMER UN LIVRE             |
PROMPT =========================================
ACCEPT id_livre PROMPT 'ID du livre a supprimer : '
PROMPT

BEGIN
    SupprimerLivre(&id_livre);
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE 
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql