SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_abonne
UNDEFINE nouveau_nom
UNDEFINE nouveau_prenom

PROMPT =========================================
PROMPT |        MODIFIER UN ABONNE             |
PROMPT =========================================
PROMPT  (Laisser vide = conserver la valeur)
PROMPT
ACCEPT id_abonne      PROMPT 'ID de l''abonne a modifier    : '
ACCEPT nouveau_nom    PROMPT 'Nouveau nom (ou Entree)      : '
ACCEPT nouveau_prenom PROMPT 'Nouveau prenom (ou Entree)   : '
PROMPT

BEGIN
    ModifierAbonne('&&id_abonne', '&&nouveau_nom', '&&nouveau_prenom');
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql