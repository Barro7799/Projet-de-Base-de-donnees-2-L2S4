SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE v_type_modif

PROMPT =========================================
PROMPT |     MODIFIER LES INFORMATIONS         |
PROMPT =========================================
PROMPT |  1. Modifier un livre                 |
PROMPT |  2. Modifier un abonne                |
PROMPT =========================================
ACCEPT v_type_modif PROMPT 'Votre choix (1 ou 2) : '

COLUMN sf8 NEW_VALUE sous_fichier8 NOPRINT
SELECT CASE
    WHEN &v_type_modif = 1 THEN 'choix_8_livre.sql'
    WHEN &v_type_modif = 2 THEN 'choix_8_abonne.sql'
    ELSE 'choix_8_abonne.sql'
END AS sf8 FROM DUAL;

@Procedures_sup\Menu_Interactif_proc_sup\&sous_fichier8