SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT ================================= 
PROMPT |         LIVRES DISPONIBLES    |
PROMPT =================================
PROMPT

BEGIN
    AfficherLivresDisponibles;
END;
/

PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql