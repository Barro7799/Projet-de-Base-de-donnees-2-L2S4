SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_livre
UNDEFINE nouveau_titre
UNDEFINE nouveau_auteur

PROMPT =========================================
PROMPT |        MODIFIER UN LIVRE              |
PROMPT =========================================
PROMPT  (Laisser vide = conserver la valeur)
PROMPT
ACCEPT id_livre        PROMPT 'ID du livre a modifier       : '
ACCEPT nouveau_titre   PROMPT 'Nouveau titre (ou Entree)    : '
ACCEPT nouveau_auteur  PROMPT 'Nouvel auteur (ou Entree)    : '
PROMPT

BEGIN
    ModifierLivre(&id_livre, '&&nouveau_titre', '&&nouveau_auteur');
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql