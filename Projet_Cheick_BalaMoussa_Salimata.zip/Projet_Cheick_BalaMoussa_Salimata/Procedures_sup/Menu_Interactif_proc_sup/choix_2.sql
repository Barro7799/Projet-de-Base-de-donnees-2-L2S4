SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_abonne
UNDEFINE nom
UNDEFINE prenom

PROMPT ================================= 
PROMPT |         AJOUTER UN ABONNE     |
PROMPT =================================
ACCEPT id_abonne PROMPT 'ID de l''abonne : '
ACCEPT nom PROMPT 'Nom du nouvel abonne : '
ACCEPT prenom PROMPT 'Prenom du nouvel abonne : '
PROMPT

BEGIN
    AjouterAbonne('&&id_abonne', '&&nom', '&&prenom');
END;
/


PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql