SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_abonne

PROMPT =========================================
PROMPT |        DESABONNER UN ABONNE           |
PROMPT =========================================
ACCEPT id_abonne PROMPT 'ID de l''abonne a desabonner : '
PROMPT

BEGIN
    DesabonnerAbonne('&&id_abonne');
END;
/

PROMPT
PROMPT Appuyez sur Entree pour continuer...
PAUSE 
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql