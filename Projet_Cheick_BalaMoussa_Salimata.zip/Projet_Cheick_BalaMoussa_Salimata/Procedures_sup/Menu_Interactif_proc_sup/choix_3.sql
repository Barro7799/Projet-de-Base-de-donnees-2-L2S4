SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_livre
UNDEFINE id_abonne

PROMPT ================================= 
PROMPT |       EMPRUNTER UN LIVRE      |
PROMPT =================================
PROMPT 
ACCEPT id_livre PROMPT 'ID livre que vous souhaitez emprunter: '
ACCEPT id_abonne PROMPT 'Votre identifiant(Matricule/INE) : '
PROMPT

BEGIN
    EmprunterLivre(&id_livre, '&&id_abonne');
END;
/

PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Procedures_sup\Menu_Interactif_proc_sup\menu.sql