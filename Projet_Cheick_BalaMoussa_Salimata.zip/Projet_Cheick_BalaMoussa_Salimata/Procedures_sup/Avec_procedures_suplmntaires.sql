-- ============================================================
-- PROJET BASE DE DONNÉES 2 - LICENCE 2 LSI
-- Sujet : Gestion d'une Bibliothèque avec Procédures PL/SQL
-- ============================================================
-- PARTIE 2 : SCRIPT DES PROCÉDURES STOCKÉES
-- ============================================================

-- Activer l'affichage des sorties DBMS_OUTPUT
SET SERVEROUTPUT ON;

-- ============================================================
-- PROCÉDURE 1 : AjouterLivre
-- Ajoute un nouveau livre dans la base de données
-- Gère le cas où le livre existe déjà (même id_Livre)
-- ============================================================
CREATE OR REPLACE PROCEDURE AjouterLivre (
    p_Titre     IN VARCHAR2,
    p_Auteur    IN VARCHAR2
) AS
    v_new_id    INTEGER;
    v_nb_total  INTEGER;
BEGIN
    -- Générer un nouvel identifiant pour le livre
    SELECT seq_livre.NEXTVAL INTO v_new_id FROM DUAL;
    
    -- Insertion du livre avec état 'DISPONIBLE' par défaut
    INSERT INTO Livre (id_Livre, Titre, Auteur, Etat)
    VALUES (v_new_id, p_Titre, p_Auteur, 'DISPONIBLE');

    -- Compter le nombre total d'exemplaires pour ce titre + auteur (après insertion)
    SELECT COUNT(*)
    INTO v_nb_total
    FROM Livre
    WHERE Titre = p_Titre AND Auteur = p_Auteur;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    -- Affichage des messages
    DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre "' || p_Titre || '" (ID=' || v_new_id || ') a été ajouté.');

    IF v_nb_total = 1 THEN
        DBMS_OUTPUT.PUT_LINE('Il y a maintenant ' || v_nb_total || ' exemplaire de "' || p_Titre || '" dans la bibliothèque.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Il y a maintenant ' || v_nb_total || ' exemplaires de "' || p_Titre || '" dans la bibliothèque.');
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE lors de l''ajout du livre : ' || SQLERRM);
END AjouterLivre;
/
-- ============================================================
-- PROCÉDURE 2 : AjouterAbonne
-- Ajoute un nouvel abonné dans la base de données
-- Gère le cas où l'abonné existe déjà (même id_Abonne)
-- ============================================================
CREATE OR REPLACE PROCEDURE AjouterAbonne (
    p_id_Abonne IN VARCHAR2,
    p_Nom       IN VARCHAR2,
    p_Prenom    IN VARCHAR2
) AS
    v_count INTEGER;
    v_total_abonnes INTEGER;
BEGIN
    -- Vérifier si l'abonné existe déjà
    SELECT COUNT(*) INTO v_count
    FROM Abonne
    WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Un abonné avec l''identifiant ' || p_id_Abonne || ' existe déjà.');
    ELSE
        -- Insertion du nouvel abonné
        INSERT INTO Abonne (id_Abonne, Nom, Prenom)
        VALUES (p_id_Abonne, INITCAP(p_Nom), INITCAP(p_Prenom));
        COMMIT;
        
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : L''abonné ' || INITCAP(p_Prenom) || ' ' || INITCAP(p_Nom) || ' (ID=' || p_id_Abonne || ') a été ajouté avec succès.');
        DBMS_OUTPUT.PUT_LINE('');
        
        -- Compter le nombre total d'abonnés
        SELECT COUNT(*) INTO v_total_abonnes FROM Abonne;
        
        -- Afficher la liste de tous les abonnés
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        DBMS_OUTPUT.PUT_LINE('+               LISTE COMPLETE DES ABONNES (APRES AJOUT)                  +');
        DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------+');
        DBMS_OUTPUT.PUT_LINE(RPAD('ID', 15) || RPAD('NOM', 25) || 'PRENOM');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 15, '-') || RPAD('-', 25, '-') || RPAD('-', 25, '-'));
        
        FOR r IN (SELECT id_Abonne, Nom, Prenom FROM Abonne ORDER BY id_Abonne) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(r.id_Abonne, 15) || 
                RPAD(r.Nom, 25) || 
                r.Prenom
            );
        END LOOP;
        
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 15, '-') || RPAD('-', 25, '-') || RPAD('-', 25, '-'));
        DBMS_OUTPUT.PUT_LINE('Total abonnés : ' || v_total_abonnes);
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------+');
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE lors de l''ajout de l''abonné : ' || SQLERRM);
END AjouterAbonne;
/


-- ============================================================
-- PROCÉDURE 3 : EmprunterLivre
-- Enregistre l'emprunt d'un livre par un abonné
-- Vérifie que le livre est disponible avant l'emprunt
-- Vérifie l'existence du livre et de l'abonné
-- ============================================================
CREATE OR REPLACE PROCEDURE EmprunterLivre (
    p_id_Livre      IN INTEGER,
    p_id_Abonne     IN VARCHAR2
) AS
    v_id_emprunt    INTEGER;
    v_etat          Livre.Etat%TYPE;
    v_titre         Livre.Titre%TYPE;
    v_auteur        Livre.Auteur%TYPE;
    v_nom           Abonne.Nom%TYPE;
    v_prenom        Abonne.Prenom%TYPE;
    v_cnt_livre     INTEGER;
    v_cnt_abo       INTEGER;
    v_nb_dispo      INTEGER;
    v_nb_total      INTEGER;
    v_nb_empruntes  INTEGER;
    v_deja_emprunte INTEGER;  -- Vérifie si même titre/auteur déjà emprunté
    v_nb_en_cours   INTEGER;  -- Nombre de livres actuellement empruntés
BEGIN
    SELECT seq_emprunt.NEXTVAL INTO v_id_emprunt FROM DUAL;

    -- 1. Vérifier l'existence du livre
    SELECT COUNT(*) INTO v_cnt_livre FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_cnt_livre = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    -- 2. Vérifier l'existence de l'abonné
    SELECT COUNT(*) INTO v_cnt_abo FROM Abonne WHERE id_Abonne = p_id_Abonne;

    IF v_cnt_abo = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    -- 3. Récupérer infos du livre et de l'abonné
    SELECT Etat, Titre, Auteur INTO v_etat, v_titre, v_auteur
    FROM Livre WHERE id_Livre = p_id_Livre;

    SELECT Nom, Prenom INTO v_nom, v_prenom
    FROM Abonne WHERE id_Abonne = p_id_Abonne;

    -- 4. Vérifier la disponibilité du livre
    IF v_etat = 'EMPRUNTE' THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') est déjà emprunté.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    -- 5. Vérifier si l'abonné a déjà emprunté un livre du même titre/auteur
    SELECT COUNT(*) INTO v_deja_emprunte
    FROM Emprunt e
    JOIN Livre l ON e.id_Livre = l.id_Livre
    WHERE e.id_Abonne = p_id_Abonne
      AND UPPER(l.Titre)  = UPPER(v_titre)
      AND UPPER(l.Auteur) = UPPER(v_auteur)
      AND e.Date_Retour IS NULL;

    IF v_deja_emprunte > 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || v_prenom || ' ' || v_nom || ' a déjà un exemplaire de "' || v_titre || '" en cours d''emprunt.');
        DBMS_OUTPUT.PUT_LINE('         Il est interdit d''emprunter deux fois le même livre.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    -- 6. Vérifier la limite de 5 livres empruntés simultanément
    SELECT COUNT(*) INTO v_nb_en_cours
    FROM Emprunt
    WHERE id_Abonne = p_id_Abonne AND Date_Retour IS NULL;

    IF v_nb_en_cours >= 5 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || v_prenom || ' ' || v_nom || ' a atteint la limite de 5 livres empruntés simultanément.');
        DBMS_OUTPUT.PUT_LINE('         Veuillez retourner un livre avant d''en emprunter un nouveau.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    -- 7. Enregistrer l'emprunt
    INSERT INTO Emprunt (id_Emprunt, id_Livre, id_Abonne, Date_Emprunt, Date_Retour)
    VALUES (v_id_emprunt, p_id_Livre, p_id_Abonne, SYSDATE, NULL);

    -- 8. Mettre à jour l'état du livre
    UPDATE Livre SET Etat = 'EMPRUNTE' WHERE id_Livre = p_id_Livre;

    -- 9. Statistiques
    SELECT COUNT(*) INTO v_nb_total
    FROM Livre WHERE Titre = v_titre AND Auteur = v_auteur;

    SELECT COUNT(*) INTO v_nb_dispo
    FROM Livre WHERE Titre = v_titre AND Auteur = v_auteur AND Etat = 'DISPONIBLE';

    v_nb_empruntes := v_nb_total - v_nb_dispo;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') a été emprunté par '
        || v_prenom || ' ' || v_nom || ' le ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || '.');
    DBMS_OUTPUT.PUT_LINE('INFO    : Il lui reste ' || (4 - v_nb_en_cours) || ' emprunt(s) possible(s) (limite : 5).');
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    DBMS_OUTPUT.PUT_LINE('STATISTIQUES POUR "' || v_titre || '" de ' || v_auteur || ' :');
    DBMS_OUTPUT.PUT_LINE('   - Total des exemplaires  : ' || v_nb_total);
    DBMS_OUTPUT.PUT_LINE('   - Exemplaires disponibles: ' || v_nb_dispo);
    DBMS_OUTPUT.PUT_LINE('   - Exemplaires empruntés  : ' || v_nb_empruntes);
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

    IF v_nb_dispo = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ATTENTION : Plus aucun exemplaire disponible de "' || v_titre || '" !');
    ELSIF v_nb_dispo = 1 THEN
        DBMS_OUTPUT.PUT_LINE('ATTENTION : Plus qu''un seul exemplaire disponible de "' || v_titre || '".');
    ELSE
        DBMS_OUTPUT.PUT_LINE('INFO : ' || v_nb_dispo || ' exemplaire(s) encore disponible(s).');
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE lors de l''emprunt : ' || SQLERRM);
END EmprunterLivre;
/

-- ============================================================
-- PROCÉDURE 4 : RetournerLivre
-- Gère le retour d'un livre (mise à jour de la disponibilité)
-- Vérifie que le livre existe et est bien emprunté
-- ============================================================
CREATE OR REPLACE PROCEDURE RetournerLivre (
    p_id_Livre IN INTEGER
) AS
    v_etat      Livre.Etat%TYPE;
    v_titre     Livre.Titre%TYPE;
    v_auteur    Livre.Auteur%TYPE;
    v_count     INTEGER;
    v_nb_dispo  INTEGER;
    v_nb_total  INTEGER;
    v_nb_emp    INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Etat, Titre, Auteur INTO v_etat, v_titre, v_auteur
    FROM Livre WHERE id_Livre = p_id_Livre;

    IF v_etat = 'DISPONIBLE' THEN
        DBMS_OUTPUT.PUT_LINE('INFORMATION : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') est déjà disponible, aucun retour à enregistrer.');
    ELSE
        -- Mettre à jour l'état du livre
        UPDATE Livre SET Etat = 'DISPONIBLE' WHERE id_Livre = p_id_Livre;

        -- Enregistrer la date de retour dans l'emprunt en cours
        UPDATE Emprunt
        SET Date_Retour = SYSDATE
        WHERE id_Livre = p_id_Livre
          AND Date_Retour IS NULL;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') a été retourné le ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY') || '.');
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

    SELECT COUNT(*) INTO v_nb_total FROM Livre WHERE Titre = v_titre AND Auteur = v_auteur;
    SELECT COUNT(*) INTO v_nb_dispo FROM Livre WHERE Titre = v_titre AND Auteur = v_auteur AND Etat = 'DISPONIBLE';
    v_nb_emp := v_nb_total - v_nb_dispo;

    DBMS_OUTPUT.PUT_LINE('STATISTIQUES POUR "' || v_titre || '" de ' || v_auteur || ' :');
    DBMS_OUTPUT.PUT_LINE('   - Total des exemplaires  : ' || v_nb_total);
    DBMS_OUTPUT.PUT_LINE('   - Exemplaires disponibles: ' || v_nb_dispo);
    DBMS_OUTPUT.PUT_LINE('   - Exemplaires empruntés  : ' || v_nb_emp);
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE lors du retour : ' || SQLERRM);
END RetournerLivre;
/
-- ============================================================
-- PROCÉDURE 5 : AfficherLivresDisponibles
-- Affiche la liste de tous les livres disponibles
-- ============================================================
CREATE OR REPLACE PROCEDURE AfficherLivresDisponibles AS
    v_total_exemplaires INTEGER;
    v_total_titres INTEGER;
    
BEGIN
    SELECT COUNT(*) INTO v_total_exemplaires FROM Livre WHERE Etat = 'DISPONIBLE';
    SELECT COUNT(DISTINCT Titre || '|' || Auteur) INTO v_total_titres 
    FROM Livre WHERE Etat = 'DISPONIBLE';

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('|                         LIVRES DISPONIBLES (par titre)                         |');
    DBMS_OUTPUT.PUT_LINE('================================================================================');
    
    IF v_total_exemplaires = 0 THEN
        DBMS_OUTPUT.PUT_LINE(' Aucun livre disponible.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('TITRE', 35) || RPAD('AUTEUR', 30) || 'EXEMPLAIRES');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 35, '-') || RPAD('-', 30, '-') || '-----------');
        
        FOR r IN (SELECT TRIM(Titre) as Titre, TRIM(Auteur) as Auteur, COUNT(*) as nb
                  FROM Livre
                  WHERE Etat = 'DISPONIBLE'
                  GROUP BY TRIM(Titre), TRIM(Auteur)
                  ORDER BY UPPER(TRIM(Titre))) LOOP
            
            DBMS_OUTPUT.PUT_LINE(
                RPAD(SUBSTR(r.Titre, 1, 33), 35) || 
                RPAD(SUBSTR(r.Auteur, 1, 28), 30) || 
                LPAD(TO_CHAR(r.nb), 11)
            );
        END LOOP;
        
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 35, '-') || RPAD('-', 30, '-') || '-----------');
        DBMS_OUTPUT.PUT_LINE('');
        DBMS_OUTPUT.PUT_LINE('Total des livres disponibles : ' || v_total_exemplaires || '   |   Total des livres distincts : ' || v_total_titres);
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END AfficherLivresDisponibles;
/

--=============================================================
-- PROCÉDURE 6 : SupprimerLivre
-- Supprime un livre de la base de données
-- Vérifie que le livre existe et n''est pas emprunté avant de le supprimer
--==============================================================

CREATE OR REPLACE PROCEDURE SupprimerLivre (
    p_id_Livre IN INTEGER
) AS
    v_count  INTEGER;
    v_etat   Livre.Etat%TYPE;
    v_titre  Livre.Titre%TYPE;
    v_auteur Livre.Auteur%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Etat, Titre, Auteur INTO v_etat, v_titre, v_auteur
    FROM Livre WHERE id_Livre = p_id_Livre;

    IF v_etat = 'EMPRUNTE' THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') est actuellement emprunté.');
        DBMS_OUTPUT.PUT_LINE('         Veuillez attendre son retour avant de le supprimer.');
    ELSE
        -- Supprimer l'historique des emprunts liés à ce livre
        DELETE FROM Emprunt WHERE id_Livre = p_id_Livre;
        -- Supprimer le livre
        DELETE FROM Livre WHERE id_Livre = p_id_Livre;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre "' || v_titre || '" de ' || v_auteur || ' (ID=' || p_id_Livre || ') a été supprimé.');
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END SupprimerLivre;
/

--=============================================================
-- PROCÉDURE 7 : DesabonnerAbonne
-- Désabonne un abonné de la bibliothèque
-- Vérifie que l''abonné existe et n''a pas d''emprunt en cours avant de le désabonner
--==============================================================
CREATE OR REPLACE PROCEDURE DesabonnerAbonne (
    p_id_Abonne IN VARCHAR2
) AS
    v_count      INTEGER;
    v_actifs     INTEGER;
    v_historique INTEGER;
    v_nom        Abonne.Nom%TYPE;
    v_prenom     Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;

    -- Vérifier les emprunts en cours
    SELECT COUNT(*) INTO v_actifs
    FROM Emprunt WHERE id_Abonne = p_id_Abonne AND Date_Retour IS NULL;

    IF v_actifs > 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || v_prenom || ' ' || v_nom || ' a encore ' || v_actifs || ' livre(s) emprunté(s) non retourné(s).');
        DBMS_OUTPUT.PUT_LINE('         Veuillez retourner tous les livres avant le désabonnement.');
    ELSE
        -- Supprimer l'historique des emprunts
        SELECT COUNT(*) INTO v_historique FROM Emprunt WHERE id_Abonne = p_id_Abonne;
        DELETE FROM Emprunt WHERE id_Abonne = p_id_Abonne;
        -- Supprimer l'abonné
        DELETE FROM Abonne WHERE id_Abonne = p_id_Abonne;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : L''abonné ' || v_prenom || ' ' || v_nom || ' (ID=' || p_id_Abonne || ') a été désabonné.');
        IF v_historique > 0 THEN
            DBMS_OUTPUT.PUT_LINE('INFO : ' || v_historique || ' enregistrement(s) d''historique supprimé(s).');
        END IF;
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END DesabonnerAbonne;
/

--=============================================================
-- PROCÉDURE 8 : ModifierLivre
-- Modifie les informations d''un livre (titre et/ou auteur)
-- Vérifie que le livre existe avant de le modifier
-- Permet de ne modifier que le titre ou que l''auteur si souhaité
--==============================================================
CREATE OR REPLACE PROCEDURE ModifierLivre (
    p_id_Livre       IN INTEGER,
    p_nouveau_titre  IN VARCHAR2,
    p_nouveau_auteur IN VARCHAR2
) AS
    v_count  INTEGER;
    v_titre  Livre.Titre%TYPE;
    v_auteur Livre.Auteur%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Titre, Auteur INTO v_titre, v_auteur FROM Livre WHERE id_Livre = p_id_Livre;

    UPDATE Livre
    SET Titre  = NVL(NULLIF(TRIM(p_nouveau_titre),  ''), Titre),
        Auteur = NVL(NULLIF(TRIM(p_nouveau_auteur), ''), Auteur)
    WHERE id_Livre = p_id_Livre;
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre (ID=' || p_id_Livre || ') a été modifié.');
    DBMS_OUTPUT.PUT_LINE('   Titre  : ' || v_titre  || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_titre),  ''), v_titre));
    DBMS_OUTPUT.PUT_LINE('   Auteur : ' || v_auteur || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_auteur), ''), v_auteur));
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END ModifierLivre;
/

--=============================================================
-- PROCÉDURE 9 : ModifierAbonne
-- Modifie les informations d''un abonné (nom et/ou prénom)
-- Vérifie que l''abonné existe avant de le modifier
-- Permet de ne modifier que le nom ou que le prénom si souhaité
--==============================================================
CREATE OR REPLACE PROCEDURE ModifierAbonne (
    p_id_Abonne      IN VARCHAR2,
    p_nouveau_nom    IN VARCHAR2,
    p_nouveau_prenom IN VARCHAR2
) AS
    v_count  INTEGER;
    v_nom    Abonne.Nom%TYPE;
    v_prenom Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;

    UPDATE Abonne
    SET Nom    = NVL(NULLIF(TRIM(p_nouveau_nom),    ''), Nom),
        Prenom = NVL(NULLIF(TRIM(p_nouveau_prenom), ''), Prenom)
    WHERE id_Abonne = p_id_Abonne;
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('SUCCÈS : L''abonné (ID=' || p_id_Abonne || ') a été modifié.');
    DBMS_OUTPUT.PUT_LINE('   Nom    : ' || v_nom    || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_nom),    ''), v_nom));
    DBMS_OUTPUT.PUT_LINE('   Prénom : ' || v_prenom || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_prenom), ''), v_prenom));
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END ModifierAbonne;
/

--=============================================================
-- PROCÉDURE 10 : AfficherTousAbonnes
-- Affiche la liste de tous les abonnés avec leurs emprunts en cours
--==============================================================
CREATE OR REPLACE PROCEDURE AfficherTousAbonnes AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Abonne;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('|                      LISTE DE TOUS LES ABONNES                              |');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun abonné enregistré.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID', 12) || RPAD('NOM', 20) || RPAD('PRENOM', 20) || 'EMPRUNTS EN COURS');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 12, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || '-----------------');

        FOR r IN (
            SELECT a.id_Abonne,
                   a.Nom,
                   a.Prenom,
                   COUNT(CASE WHEN e.Date_Retour IS NULL THEN 1 END) AS nb_en_cours
            FROM Abonne a
            LEFT JOIN Emprunt e ON a.id_Abonne = e.id_Abonne
            GROUP BY a.id_Abonne, a.Nom, a.Prenom
            ORDER BY a.Nom, a.Prenom
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(SUBSTR(TO_CHAR(r.id_Abonne), 1, 10), 12) ||
                RPAD(SUBSTR(r.Nom,    1, 18), 20) ||
                RPAD(SUBSTR(r.Prenom, 1, 18), 20) ||
                LPAD(TO_CHAR(r.nb_en_cours), 17)
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 12, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || '-----------------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' abonné(s)');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END AfficherTousAbonnes;
/

--=============================================================
-- PROCÉDURE 11 : AfficherEmpruntsEnCours
-- Affiche la liste de tous les emprunts en cours avec les détails du livre et de l''abonné
--==============================================================
CREATE OR REPLACE PROCEDURE AfficherEmpruntsEnCours AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Emprunt WHERE Date_Retour IS NULL;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('|                          EMPRUNTS EN COURS                                  |');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun emprunt en cours actuellement.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID_EMP', 8) || RPAD('TITRE', 30) || RPAD('ABONNE', 25) || 'DATE EMPRUNT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 8, '-') || RPAD('-', 30, '-') || RPAD('-', 25, '-') || '------------');

        FOR r IN (
            SELECT e.id_Emprunt,
                   l.Titre,
                   a.Nom || ' ' || a.Prenom AS abonne,
                   TO_CHAR(e.Date_Emprunt, 'DD/MM/YYYY') AS dt_emprunt
            FROM Emprunt e
            JOIN Livre   l ON e.id_Livre   = l.id_Livre
            JOIN Abonne  a ON e.id_Abonne  = a.id_Abonne
            WHERE e.Date_Retour IS NULL
            ORDER BY e.Date_Emprunt
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(TO_CHAR(r.id_Emprunt), 8) ||
                RPAD(SUBSTR(r.Titre,  1, 28), 30) ||
                RPAD(SUBSTR(r.abonne, 1, 23), 25) ||
                r.dt_emprunt
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 8, '-') || RPAD('-', 30, '-') || RPAD('-', 25, '-') || '------------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' emprunt(s) en cours');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END AfficherEmpruntsEnCours;
/

--=============================================================
-- PROCÉDURE 12 : HistoriqueEmpruntsAbonne
-- Affiche l''historique complet des emprunts d''un abonné (livres empruntés, dates d''emprunt et de retour, statut actuel)
-- Vérifie que l''abonné existe avant d''afficher l''historique
--==============================================================
CREATE OR REPLACE PROCEDURE HistoriqueEmpruntsAbonne (
    p_id_Abonne IN VARCHAR2
) AS
    v_count  INTEGER;
    v_total  INTEGER;
    v_nom    Abonne.Nom%TYPE;
    v_prenom Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('================================================================================');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;
    SELECT COUNT(*) INTO v_total FROM Emprunt WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('|  HISTORIQUE DES EMPRUNTS DE : ' || UPPER(v_prenom) || ' ' || UPPER(v_nom) || ' (ID=' || p_id_Abonne || ')');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun emprunt enregistré pour cet abonné.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('TITRE', 32) || RPAD('DATE EMPRUNT', 15) || RPAD('DATE RETOUR', 15) || 'STATUT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 32, '-') || RPAD('-', 15, '-') || RPAD('-', 15, '-') || '----------');

        FOR r IN (
            SELECT l.Titre,
                   TO_CHAR(e.Date_Emprunt, 'DD/MM/YYYY') AS dt_emprunt,
                   TO_CHAR(e.Date_Retour,  'DD/MM/YYYY') AS dt_retour,
                   CASE WHEN e.Date_Retour IS NULL THEN 'EN COURS' ELSE 'RETOURNE' END AS statut
            FROM Emprunt e
            JOIN Livre l ON e.id_Livre = l.id_Livre
            WHERE e.id_Abonne = p_id_Abonne
            ORDER BY e.Date_Emprunt DESC
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(SUBSTR(r.Titre, 1, 30), 32) ||
                RPAD(r.dt_emprunt, 15) ||
                RPAD(NVL(r.dt_retour, '-'), 15) ||
                r.statut
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 32, '-') || RPAD('-', 15, '-') || RPAD('-', 15, '-') || '----------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' emprunt(s)');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END HistoriqueEmpruntsAbonne;
/

--=============================================================
-- PROCÉDURE 13 : RechercherLivre
-- Permet de rechercher des livres par titre ou par auteur
-- Affiche les résultats de la recherche avec les détails du livre et son état actuel
-- Vérifie que le type de recherche est valide (titre ou auteur)
--==============================================================
CREATE OR REPLACE PROCEDURE RechercherLivre (
    p_mot_cle IN VARCHAR2,
    p_type    IN VARCHAR2  -- 'TITRE' ou 'AUTEUR'
) AS
    v_total INTEGER;
    v_type  VARCHAR2(10) := UPPER(TRIM(p_type));
BEGIN
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_type NOT IN ('TITRE', 'AUTEUR') THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Type invalide. Saisissez TITRE ou AUTEUR.');
        DBMS_OUTPUT.PUT_LINE('================================================================================');
        RETURN;
    END IF;

    IF v_type = 'TITRE' THEN
        SELECT COUNT(*) INTO v_total FROM Livre WHERE UPPER(Titre) LIKE '%' || UPPER(p_mot_cle) || '%';
    ELSE
        SELECT COUNT(*) INTO v_total FROM Livre WHERE UPPER(Auteur) LIKE '%' || UPPER(p_mot_cle) || '%';
    END IF;

    DBMS_OUTPUT.PUT_LINE('|  RECHERCHE PAR ' || v_type || ' : "' || p_mot_cle || '"');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun livre trouvé pour "' || p_mot_cle || '".');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID', 6) || RPAD('TITRE', 35) || RPAD('AUTEUR', 25) || 'ETAT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 6, '-') || RPAD('-', 35, '-') || RPAD('-', 25, '-') || '----------');

        IF v_type = 'TITRE' THEN
            FOR r IN (
                SELECT id_Livre, Titre, Auteur, Etat FROM Livre
                WHERE UPPER(Titre) LIKE '%' || UPPER(p_mot_cle) || '%'
                ORDER BY Titre
            ) LOOP
                DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.id_Livre),6)||RPAD(SUBSTR(r.Titre,1,33),35)||RPAD(SUBSTR(r.Auteur,1,23),25)||r.Etat);
            END LOOP;
        ELSE
            FOR r IN (
                SELECT id_Livre, Titre, Auteur, Etat FROM Livre
                WHERE UPPER(Auteur) LIKE '%' || UPPER(p_mot_cle) || '%'
                ORDER BY Auteur, Titre
            ) LOOP
                DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.id_Livre),6)||RPAD(SUBSTR(r.Titre,1,33),35)||RPAD(SUBSTR(r.Auteur,1,23),25)||r.Etat);
            END LOOP;
        END IF;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 6, '-') || RPAD('-', 35, '-') || RPAD('-', 25, '-') || '----------');
        DBMS_OUTPUT.PUT_LINE('  ' || v_total || ' résultat(s) trouvé(s).');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END RechercherLivre;
/


-- ============================================================
-- VÉRIFICATION : Afficher les procédures créées
-- ============================================================
SELECT OBJECT_NAME, STATUS
FROM USER_OBJECTS
WHERE OBJECT_TYPE = 'PROCEDURE' AND OBJECT_NAME IN ('AJOUTERLIVRE', 'AJOUTERABONNE', 'EMPRUNTERLIVRE', 'RETOURNERLIVRE', 'AFFICHERLIVRESDISPONIBLES', 'SUPPRIMERLIVRE', 'DESABONNERABONNE', 'MODIFIERLIVRE', 'MODIFIERABONNE', 'AFFICHERTOUSABONNES', 'AFFICHEREMPRUNTSENCOURS', 'HISTORIQUEEMPRUNTSABONNE', 'RECHERCHERLIVRE')
ORDER BY OBJECT_NAME;
