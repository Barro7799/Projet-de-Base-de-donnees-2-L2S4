
SET SERVEROUTPUT ON;

--=============================================================
-- PROCÉDURE 6 : SupprimerLivre
-- Supprime un livre de la base de données
-- Vérifie que le livre existe et n''est pas emprunté avant de le supprimer
--==============================================================

CREATE OR REPLACE PROCEDURE SupprimerLivre (
    p_id_Livre IN INTEGER
) AS
    v_count  INTEGER;
    v_etat   Livre.Etat%TYPE;
    v_titre  Livre.Titre%TYPE;
    v_auteur Livre.Auteur%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Etat, Titre, Auteur INTO v_etat, v_titre, v_auteur
    FROM Livre WHERE id_Livre = p_id_Livre;

    IF v_etat = 'EMPRUNTE' THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Le livre "' || v_titre || '" (ID=' || p_id_Livre || ') est actuellement emprunté.');
        DBMS_OUTPUT.PUT_LINE('         Veuillez attendre son retour avant de le supprimer.');
    ELSE
        -- Supprimer l'historique des emprunts liés à ce livre
        DELETE FROM Emprunt WHERE id_Livre = p_id_Livre;
        -- Supprimer le livre
        DELETE FROM Livre WHERE id_Livre = p_id_Livre;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre "' || v_titre || '" de ' || v_auteur || ' (ID=' || p_id_Livre || ') a été supprimé.');
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END SupprimerLivre;
/

--=============================================================
-- PROCÉDURE 7 : DesabonnerAbonne
-- Désabonne un abonné de la bibliothèque
-- Vérifie que l''abonné existe et n''a pas d''emprunt en cours avant de le désabonner
--==============================================================
CREATE OR REPLACE PROCEDURE DesabonnerAbonne (
    p_id_Abonne IN VARCHAR2
) AS
    v_count      INTEGER;
    v_actifs     INTEGER;
    v_historique INTEGER;
    v_nom        Abonne.Nom%TYPE;
    v_prenom     Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;

    -- Vérifier les emprunts en cours
    SELECT COUNT(*) INTO v_actifs
    FROM Emprunt WHERE id_Abonne = p_id_Abonne AND Date_Retour IS NULL;

    IF v_actifs > 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || v_prenom || ' ' || v_nom || ' a encore ' || v_actifs || ' livre(s) emprunté(s) non retourné(s).');
        DBMS_OUTPUT.PUT_LINE('         Veuillez retourner tous les livres avant le désabonnement.');
    ELSE
        -- Supprimer l'historique des emprunts
        SELECT COUNT(*) INTO v_historique FROM Emprunt WHERE id_Abonne = p_id_Abonne;
        DELETE FROM Emprunt WHERE id_Abonne = p_id_Abonne;
        -- Supprimer l'abonné
        DELETE FROM Abonne WHERE id_Abonne = p_id_Abonne;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCÈS : L''abonné ' || v_prenom || ' ' || v_nom || ' (ID=' || p_id_Abonne || ') a été désabonné.');
        IF v_historique > 0 THEN
            DBMS_OUTPUT.PUT_LINE('INFO : ' || v_historique || ' enregistrement(s) d''historique supprimé(s).');
        END IF;
    END IF;
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END DesabonnerAbonne;
/

--=============================================================
-- PROCÉDURE 8 : ModifierLivre
-- Modifie les informations d''un livre (titre et/ou auteur)
-- Vérifie que le livre existe avant de le modifier
-- Permet de ne modifier que le titre ou que l''auteur si souhaité
--==============================================================
CREATE OR REPLACE PROCEDURE ModifierLivre (
    p_id_Livre       IN INTEGER,
    p_nouveau_titre  IN VARCHAR2,
    p_nouveau_auteur IN VARCHAR2
) AS
    v_count  INTEGER;
    v_titre  Livre.Titre%TYPE;
    v_auteur Livre.Auteur%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Livre WHERE id_Livre = p_id_Livre;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun livre trouvé avec l''identifiant ' || p_id_Livre || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Titre, Auteur INTO v_titre, v_auteur FROM Livre WHERE id_Livre = p_id_Livre;

    UPDATE Livre
    SET Titre  = NVL(NULLIF(TRIM(p_nouveau_titre),  ''), Titre),
        Auteur = NVL(NULLIF(TRIM(p_nouveau_auteur), ''), Auteur)
    WHERE id_Livre = p_id_Livre;
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('SUCCÈS : Le livre (ID=' || p_id_Livre || ') a été modifié.');
    DBMS_OUTPUT.PUT_LINE('   Titre  : ' || v_titre  || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_titre),  ''), v_titre));
    DBMS_OUTPUT.PUT_LINE('   Auteur : ' || v_auteur || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_auteur), ''), v_auteur));
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END ModifierLivre;
/

--=============================================================
-- PROCÉDURE 9 : ModifierAbonne
-- Modifie les informations d''un abonné (nom et/ou prénom)
-- Vérifie que l''abonné existe avant de le modifier
-- Permet de ne modifier que le nom ou que le prénom si souhaité
--==============================================================
CREATE OR REPLACE PROCEDURE ModifierAbonne (
    p_id_Abonne      IN VARCHAR2,
    p_nouveau_nom    IN VARCHAR2,
    p_nouveau_prenom IN VARCHAR2
) AS
    v_count  INTEGER;
    v_nom    Abonne.Nom%TYPE;
    v_prenom Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;

    UPDATE Abonne
    SET Nom    = NVL(NULLIF(TRIM(p_nouveau_nom),    ''), Nom),
        Prenom = NVL(NULLIF(TRIM(p_nouveau_prenom), ''), Prenom)
    WHERE id_Abonne = p_id_Abonne;
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('SUCCÈS : L''abonné (ID=' || p_id_Abonne || ') a été modifié.');
    DBMS_OUTPUT.PUT_LINE('   Nom    : ' || v_nom    || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_nom),    ''), v_nom));
    DBMS_OUTPUT.PUT_LINE('   Prénom : ' || v_prenom || '  ->  ' || NVL(NULLIF(TRIM(p_nouveau_prenom), ''), v_prenom));
    DBMS_OUTPUT.PUT_LINE('+-------------------------------------------------------------------------+');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERREUR INATTENDUE : ' || SQLERRM);
END ModifierAbonne;
/

--=============================================================
-- PROCÉDURE 10 : AfficherTousAbonnes
-- Affiche la liste de tous les abonnés avec leurs emprunts en cours
--==============================================================
CREATE OR REPLACE PROCEDURE AfficherTousAbonnes AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Abonne;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('|                      LISTE DE TOUS LES ABONNES                              |');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun abonné enregistré.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID', 12) || RPAD('NOM', 20) || RPAD('PRENOM', 20) || 'EMPRUNTS EN COURS');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 12, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || '-----------------');

        FOR r IN (
            SELECT a.id_Abonne,
                   a.Nom,
                   a.Prenom,
                   COUNT(CASE WHEN e.Date_Retour IS NULL THEN 1 END) AS nb_en_cours
            FROM Abonne a
            LEFT JOIN Emprunt e ON a.id_Abonne = e.id_Abonne
            GROUP BY a.id_Abonne, a.Nom, a.Prenom
            ORDER BY a.Nom, a.Prenom
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(SUBSTR(TO_CHAR(r.id_Abonne), 1, 10), 12) ||
                RPAD(SUBSTR(r.Nom,    1, 18), 20) ||
                RPAD(SUBSTR(r.Prenom, 1, 18), 20) ||
                LPAD(TO_CHAR(r.nb_en_cours), 17)
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 12, '-') || RPAD('-', 20, '-') || RPAD('-', 20, '-') || '-----------------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' abonné(s)');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END AfficherTousAbonnes;
/

--=============================================================
-- PROCÉDURE 11 : AfficherEmpruntsEnCours
-- Affiche la liste de tous les emprunts en cours avec les détails du livre et de l''abonné
--==============================================================
CREATE OR REPLACE PROCEDURE AfficherEmpruntsEnCours AS
    v_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Emprunt WHERE Date_Retour IS NULL;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    DBMS_OUTPUT.PUT_LINE('|                          EMPRUNTS EN COURS                                  |');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun emprunt en cours actuellement.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID_EMP', 8) || RPAD('TITRE', 30) || RPAD('ABONNE', 25) || 'DATE EMPRUNT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 8, '-') || RPAD('-', 30, '-') || RPAD('-', 25, '-') || '------------');

        FOR r IN (
            SELECT e.id_Emprunt,
                   l.Titre,
                   a.Nom || ' ' || a.Prenom AS abonne,
                   TO_CHAR(e.Date_Emprunt, 'DD/MM/YYYY') AS dt_emprunt
            FROM Emprunt e
            JOIN Livre   l ON e.id_Livre   = l.id_Livre
            JOIN Abonne  a ON e.id_Abonne  = a.id_Abonne
            WHERE e.Date_Retour IS NULL
            ORDER BY e.Date_Emprunt
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(TO_CHAR(r.id_Emprunt), 8) ||
                RPAD(SUBSTR(r.Titre,  1, 28), 30) ||
                RPAD(SUBSTR(r.abonne, 1, 23), 25) ||
                r.dt_emprunt
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 8, '-') || RPAD('-', 30, '-') || RPAD('-', 25, '-') || '------------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' emprunt(s) en cours');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END AfficherEmpruntsEnCours;
/

--=============================================================
-- PROCÉDURE 12 : HistoriqueEmpruntsAbonne
-- Affiche l''historique complet des emprunts d''un abonné (livres empruntés, dates d''emprunt et de retour, statut actuel)
-- Vérifie que l''abonné existe avant d''afficher l''historique
--==============================================================
CREATE OR REPLACE PROCEDURE HistoriqueEmpruntsAbonne (
    p_id_Abonne IN VARCHAR2
) AS
    v_count  INTEGER;
    v_total  INTEGER;
    v_nom    Abonne.Nom%TYPE;
    v_prenom Abonne.Prenom%TYPE;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Abonne WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('================================================================================');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Aucun abonné trouvé avec l''identifiant ' || p_id_Abonne || '.');
        DBMS_OUTPUT.PUT_LINE('================================================================================');
        RETURN;
    END IF;

    SELECT Nom, Prenom INTO v_nom, v_prenom FROM Abonne WHERE id_Abonne = p_id_Abonne;
    SELECT COUNT(*) INTO v_total FROM Emprunt WHERE id_Abonne = p_id_Abonne;

    DBMS_OUTPUT.PUT_LINE('|  HISTORIQUE DES EMPRUNTS DE : ' || UPPER(v_prenom) || ' ' || UPPER(v_nom) || ' (ID=' || p_id_Abonne || ')');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun emprunt enregistré pour cet abonné.');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('TITRE', 32) || RPAD('DATE EMPRUNT', 15) || RPAD('DATE RETOUR', 15) || 'STATUT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 32, '-') || RPAD('-', 15, '-') || RPAD('-', 15, '-') || '----------');

        FOR r IN (
            SELECT l.Titre,
                   TO_CHAR(e.Date_Emprunt, 'DD/MM/YYYY') AS dt_emprunt,
                   TO_CHAR(e.Date_Retour,  'DD/MM/YYYY') AS dt_retour,
                   CASE WHEN e.Date_Retour IS NULL THEN 'EN COURS' ELSE 'RETOURNE' END AS statut
            FROM Emprunt e
            JOIN Livre l ON e.id_Livre = l.id_Livre
            WHERE e.id_Abonne = p_id_Abonne
            ORDER BY e.Date_Emprunt DESC
        ) LOOP
            DBMS_OUTPUT.PUT_LINE(
                RPAD(SUBSTR(r.Titre, 1, 30), 32) ||
                RPAD(r.dt_emprunt, 15) ||
                RPAD(NVL(r.dt_retour, '-'), 15) ||
                r.statut
            );
        END LOOP;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 32, '-') || RPAD('-', 15, '-') || RPAD('-', 15, '-') || '----------');
        DBMS_OUTPUT.PUT_LINE('  Total : ' || v_total || ' emprunt(s)');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END HistoriqueEmpruntsAbonne;
/

--=============================================================
-- PROCÉDURE 13 : RechercherLivre
-- Permet de rechercher des livres par titre ou par auteur
-- Affiche les résultats de la recherche avec les détails du livre et son état actuel
-- Vérifie que le type de recherche est valide (titre ou auteur)
--==============================================================
CREATE OR REPLACE PROCEDURE RechercherLivre (
    p_mot_cle IN VARCHAR2,
    p_type    IN VARCHAR2  -- 'TITRE' ou 'AUTEUR'
) AS
    v_total INTEGER;
    v_type  VARCHAR2(10) := UPPER(TRIM(p_type));
BEGIN
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_type NOT IN ('TITRE', 'AUTEUR') THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : Type invalide. Saisissez TITRE ou AUTEUR.');
        DBMS_OUTPUT.PUT_LINE('================================================================================');
        RETURN;
    END IF;

    IF v_type = 'TITRE' THEN
        SELECT COUNT(*) INTO v_total FROM Livre WHERE UPPER(Titre) LIKE '%' || UPPER(p_mot_cle) || '%';
    ELSE
        SELECT COUNT(*) INTO v_total FROM Livre WHERE UPPER(Auteur) LIKE '%' || UPPER(p_mot_cle) || '%';
    END IF;

    DBMS_OUTPUT.PUT_LINE('|  RECHERCHE PAR ' || v_type || ' : "' || p_mot_cle || '"');
    DBMS_OUTPUT.PUT_LINE('================================================================================');

    IF v_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('  Aucun livre trouvé pour "' || p_mot_cle || '".');
    ELSE
        DBMS_OUTPUT.PUT_LINE(RPAD('ID', 6) || RPAD('TITRE', 35) || RPAD('AUTEUR', 25) || 'ETAT');
        DBMS_OUTPUT.PUT_LINE(RPAD('-', 6, '-') || RPAD('-', 35, '-') || RPAD('-', 25, '-') || '----------');

        IF v_type = 'TITRE' THEN
            FOR r IN (
                SELECT id_Livre, Titre, Auteur, Etat FROM Livre
                WHERE UPPER(Titre) LIKE '%' || UPPER(p_mot_cle) || '%'
                ORDER BY Titre
            ) LOOP
                DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.id_Livre),6)||RPAD(SUBSTR(r.Titre,1,33),35)||RPAD(SUBSTR(r.Auteur,1,23),25)||r.Etat);
            END LOOP;
        ELSE
            FOR r IN (
                SELECT id_Livre, Titre, Auteur, Etat FROM Livre
                WHERE UPPER(Auteur) LIKE '%' || UPPER(p_mot_cle) || '%'
                ORDER BY Auteur, Titre
            ) LOOP
                DBMS_OUTPUT.PUT_LINE(RPAD(TO_CHAR(r.id_Livre),6)||RPAD(SUBSTR(r.Titre,1,33),35)||RPAD(SUBSTR(r.Auteur,1,23),25)||r.Etat);
            END LOOP;
        END IF;

        DBMS_OUTPUT.PUT_LINE(RPAD('-', 6, '-') || RPAD('-', 35, '-') || RPAD('-', 25, '-') || '----------');
        DBMS_OUTPUT.PUT_LINE('  ' || v_total || ' résultat(s) trouvé(s).');
    END IF;
    DBMS_OUTPUT.PUT_LINE('================================================================================');

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERREUR : ' || SQLERRM);
END RechercherLivre;
/


-- ============================================================
-- VÉRIFICATION : Afficher les procédures créées
-- ============================================================
SELECT OBJECT_NAME, STATUS
FROM USER_OBJECTS
WHERE OBJECT_TYPE = 'PROCEDURE' AND OBJECT_NAME IN ('SUPPRIMERLIVRE', 'DESABONNERABONNE', 'MODIFIERLIVRE', 'MODIFIERABONNE', 'AFFICHERTOUSABONNES', 'AFFICHEREMPRUNTSENCOURS', 'HISTORIQUEEMPRUNTSABONNE', 'RECHERCHERLIVRE')
ORDER BY OBJECT_NAME;
