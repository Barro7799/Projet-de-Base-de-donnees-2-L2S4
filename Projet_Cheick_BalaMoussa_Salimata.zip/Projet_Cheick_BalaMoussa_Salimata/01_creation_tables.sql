-- ============================================================
-- PROJET BASE DE DONNÉES 2 - LICENCE 2 LSI
-- Sujet : Gestion d'une Bibliothèque avec Procédures PL/SQL
-- Enseignant : Dr Go Issa TRAORE
-- ============================================================
-- PARTIE 1 : SCRIPT DE CRÉATION DES TABLES
-- ============================================================

-- Configuration de la session pour le français et UTF8
ALTER SESSION SET NLS_LANGUAGE = 'FRENCH';
ALTER SESSION SET NLS_TERRITORY = 'FRANCE';

-- Suppression des tables si elles existent déjà (pour réinitialiser)
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE Emprunt CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE Livre CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE Abonne CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- ============================================================
-- TABLE : Livre
-- ============================================================
CREATE TABLE Livre (
    id_Livre    INTEGER         CONSTRAINT pk_livre PRIMARY KEY,
    Titre       VARCHAR2(100)   NOT NULL,
    Auteur      VARCHAR2(100)   NOT NULL,
    Etat        VARCHAR2(20)    DEFAULT 'DISPONIBLE'
                                CONSTRAINT ck_etat_livre CHECK (Etat IN ('DISPONIBLE', 'EMPRUNTE'))
);

-- ============================================================
-- TABLE : Abonne
-- ============================================================
CREATE TABLE Abonne (
    id_Abonne   VARCHAR2(40)    CONSTRAINT pk_abonne PRIMARY KEY,
    Nom         VARCHAR2(50)    NOT NULL,
    Prenom      VARCHAR2(50)    NOT NULL
);

-- ============================================================
-- TABLE : Emprunt
-- ============================================================
CREATE TABLE Emprunt (
    id_Emprunt      INTEGER     CONSTRAINT pk_emprunt PRIMARY KEY,
    id_Livre        INTEGER     NOT NULL
                                CONSTRAINT fk_emprunt_livre REFERENCES Livre(id_Livre),
    id_Abonne       VARCHAR2(40)     NOT NULL
                                CONSTRAINT fk_emprunt_abonne REFERENCES Abonne(id_Abonne),
    Date_Emprunt    DATE        DEFAULT SYSDATE NOT NULL,
    Date_Retour      DATE         NULL
);

-- ============================================================
-- SÉQUENCES pour les identifiants auto-incrémentés
-- ============================================================
DROP SEQUENCE seq_livre;
DROP SEQUENCE seq_abonne;
DROP SEQUENCE seq_emprunt;

CREATE SEQUENCE seq_livre START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_abonne START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_emprunt START WITH 1 INCREMENT BY 1;

-- ============================================================
-- INSERTION DES DONNÉES DE TEST
-- ============================================================

-- Données initiales pour la table Livre
INSERT INTO Livre VALUES (seq_livre.nextval, 'L''Étranger',             'Albert Camus',             'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'Les Misérables',          'Victor Hugo',              'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'Germinal',                'Emile Zola',               'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'Le Rouge et le Noir',     'Stendhal',                 'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'Madame Bovary',           'Gustave Flaubert',         'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'Les Fleurs du Mal',       'Charles Baudelaire',       'DISPONIBLE');
INSERT INTO Livre VALUES (seq_livre.nextval, 'La Peste',                'Albert Camus',             'DISPONIBLE');

-- Données initiales pour la table Abonne
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'DIALLO',   'Moussa');
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'TRAORE',   'Aminata');
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'KONATE',   'Ibrahim');
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'BARRO',    'Balamoussa');
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'OUARI',    'Ousmane');
INSERT INTO Abonne VALUES (seq_abonne.nextval, 'SOULAMA',  'O.Salimata');

COMMIT;

-- ============================================================
-- VÉRIFICATION
-- ============================================================
SELECT 'TABLE LIVRE' AS Info, COUNT(*) AS Nombre FROM Livre
UNION ALL
SELECT 'TABLE ABONNE', COUNT(*) FROM Abonne
UNION ALL
SELECT 'TABLE EMPRUNT', COUNT(*) FROM Emprunt;

SELECT * FROM Livre;
SELECT * FROM Abonne;
SELECT * FROM Emprunt;