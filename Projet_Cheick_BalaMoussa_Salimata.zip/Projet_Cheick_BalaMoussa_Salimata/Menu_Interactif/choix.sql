-- choix_.sql (fichier pour les choix invalides)
SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT ============================================
PROMPT |  ERREUR : Option invalide !              |
PROMPT |  Veuillez choisir un nombre entre 1 et 6.|
PROMPT ============================================
PROMPT

PAUSE Appuyez sur Entree pour continuer...

-- Revenir au menu principal
@Menu_Interactif\menu.sql


