SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_abonne
UNDEFINE nom
UNDEFINE prenom

PROMPT ================================= 
PROMPT |         AJOUTER UN ABONNE     |
PROMPT =================================
ACCEPT id_abonne PROMPT 'ID du nouvel abonne(Matriule/INE): '
ACCEPT nom PROMPT 'Nom du nouvel abonne : '
ACCEPT prenom PROMPT 'Prenom du nouvel abonne : '
PROMPT

BEGIN
    AjouterAbonne('&&id_abonne', '&&nom', '&&prenom');
END;
/


PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Menu_Interactif\menu.sql