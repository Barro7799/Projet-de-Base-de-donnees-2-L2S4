SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT ================================= 
PROMPT |         LIVRES DISPONIBLES    |
PROMPT =================================
PROMPT

BEGIN
    AfficherLivresDisponibles;
END;
/

PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Menu_Interactif\menu.sql