-- ============================================================
-- MENU PRINCIPAL (fichier: menu.sql)
-- ============================================================
SET SERVEROUTPUT ON;
SET VERIFY OFF;

PROMPT
PROMPT ========================================
PROMPT | BIENVENUE DANS LE SYSTEME DE GESTION |
PROMPT |          DE LA BIBLIOTHEQUE          |
PROMPT ========================================
PROMPT ======================================== 
PROMPT |             MENU PRINCIPAL           |
PROMPT ========================================
PROMPT |  1. Ajouter un livre                 |
PROMPT |  2. Ajouter un abonne                |
PROMPT |  3. Emprunter un livre               |
PROMPT |  4. Retourner un livre               |
PROMPT |  5. Afficher les livres disponibles  |
PROMPT |  6. Quitter                          |
PROMPT ========================================
PROMPT

ACCEPT v_choix PROMPT 'Bienvenue!! Quelle operation souhaitez-vous effectuer (1-6) : '

-- Variable pour stocker le nom du fichier
COLUMN nom_fichier NEW_VALUE fichier_a_executer NOPRINT
-- Déterminer le fichier à exécuter selon le choix
SELECT CASE 
    WHEN &v_choix = 1 THEN 'choix_1.sql'
    WHEN &v_choix = 2 THEN 'choix_2.sql'
    WHEN &v_choix = 3 THEN 'choix_3.sql'
    WHEN &v_choix = 4 THEN 'choix_4.sql'
    WHEN &v_choix = 5 THEN 'choix_5.sql'
    WHEN &v_choix = 6 THEN 'choix_6.sql'
    ELSE 'choix.sql'
END AS nom_fichier
FROM DUAL;

-- Exécuter le fichier correspondant
@Menu_Interactif\&fichier_a_executer