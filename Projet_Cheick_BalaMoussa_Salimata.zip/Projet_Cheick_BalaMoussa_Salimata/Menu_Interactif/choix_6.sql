PROMPT ===========================================
PROMPT |VOUS AVEZ CHOISI DE QUITTER LE PROGRAMME |
PROMPT |    ANITCHE|BARKA|FOFO|THANKS|MERCI      |
PROMPT |     D'AVOIR UTILISE NOTRE SYSTEME       |
PROMPT |               AU REVOIR !               |
PROMPT ===========================================
PROMPT Fin du programme.
