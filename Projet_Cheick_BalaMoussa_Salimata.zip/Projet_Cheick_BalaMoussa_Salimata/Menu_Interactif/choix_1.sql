SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE titre
UNDEFINE auteur

PROMPT ================================= 
PROMPT |         AJOUTER UN LIVRE      |
PROMPT ================================= 
ACCEPT titre PROMPT 'Titre du livre à ajouter: '
ACCEPT auteur PROMPT 'Auteur du livre à ajouter: '
PROMPT

BEGIN
    AjouterLivre('&&titre', '&&auteur');
END;
/

PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Menu_Interactif\menu.sql