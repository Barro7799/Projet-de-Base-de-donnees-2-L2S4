SET SERVEROUTPUT ON;
SET VERIFY OFF;

UNDEFINE id_livre

PROMPT ================================= 
PROMPT |         RETOURNER UN LIVRE    |
PROMPT =================================
ACCEPT id_livre PROMPT 'ID du livre a retourner : '
PROMPT

BEGIN
    RetournerLivre(&id_livre);
END;
/

PROMPT 
PROMPT Appuyez sur Entree pour continuer...
PAUSE
@Menu_Interactif\menu.sql