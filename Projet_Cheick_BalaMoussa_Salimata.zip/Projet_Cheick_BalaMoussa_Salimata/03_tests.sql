-- ============================================================
-- PROJET BASE DE DONNÉES 2 - LICENCE 2 LSI
-- Sujet : Gestion d'une Bibliothèque avec Procédures PL/SQL
-- ============================================================
-- PARTIE 4 : SCRIPT DE TESTS
-- ============================================================

SET SERVEROUTPUT ON;

-- ============================================================
-- TEST 1 : Ajout de livres (cas normaux)
-- ============================================================
PROMPT
PROMPT ======= TEST 1 : AJOUT DE LIVRES (CAS NORMAUX) =======
/

BEGIN
    -- Ajout d'un nouveau livre
    AjouterLivre( 'Le Comte de Monte-Cristo', 'Alexandre Dumas');
    AjouterLivre( 'Notre-Dame de Paris', 'Victor Hugo');
END;
/

SELECT id_Livre, Titre, Auteur, Etat FROM Livre ORDER BY id_Livre;

-- ============================================================
-- TEST 2 : Ajout d'abonnés (cas normaux)
-- ============================================================
PROMPT
PROMPT ======= TEST 2 : AJOUT D''ABONNÉS (CAS NORMAUX) =======
/

BEGIN
    AjouterAbonne(7, 'OUEDRAOGO', 'Fatima');
    AjouterAbonne(8, 'SAWADOGO', 'Adama');
END;
/

SELECT id_Abonne, Nom, Prenom FROM Abonne ORDER BY id_Abonne;

-- ============================================================
-- TEST 3 : Ajout d'un abonné déjà existant (gestion d'erreur)
-- ============================================================
PROMPT
PROMPT ======= TEST 3 : AJOUT ABONNÉ EXISTANT (ERREUR) =======
/

BEGIN
    AjouterAbonne(5, 'SAWADOGO', 'Adama');
END;
/

-- ============================================================
-- TEST 4 : Affichage des livres disponibles (avant emprunt)
-- ============================================================
PROMPT
PROMPT ======= TEST 4 : LIVRES DISPONIBLES AVANT EMPRUNT =======
/

BEGIN
    AfficherLivresDisponibles;
END;
/

-- ============================================================
-- TEST 5 : Emprunt de livres (cas normaux)
-- ============================================================
PROMPT
PROMPT ======= TEST 5 : EMPRUNT DE LIVRES (CAS NORMAUX) =======
/

BEGIN
    -- Emprunt du livre 1 par l'abonné 1
    EmprunterLivre(1, 1);
    -- Emprunt du livre 3 par l'abonné 2
    EmprunterLivre(3, 2);
END;
/

SELECT id_Livre, Titre, Etat FROM Livre ORDER BY id_Livre;
SELECT id_Emprunt, id_Livre, id_Abonne, TO_CHAR(Date_Emprunt,'DD/MM/YYYY') AS Date_Emprunt FROM Emprunt;

-- ============================================================
-- TEST 6 : Emprunt d'un livre non disponible (gestion d'erreur)
-- ============================================================
PROMPT
PROMPT ======= TEST 6 : EMPRUNT LIVRE NON DISPONIBLE (ERREUR) =======
/

BEGIN
    -- Tentative d'emprunt du livre 1 qui est déjà emprunté
    EmprunterLivre(1, 1);
END;
/

-- ============================================================
-- TEST 7 : Emprunt avec un livre inexistant (gestion d'erreur)
-- ============================================================
PROMPT
PROMPT ======= TEST 7 : EMPRUNT LIVRE INEXISTANT (ERREUR) =======
/

BEGIN
    -- Tentative d'emprunt avec un ID de livre inexistant
    EmprunterLivre(99, 1);
END;
/

-- ============================================================
-- TEST 8 : Retour d'un livre (cas normal)
-- ============================================================
PROMPT
PROMPT ======= TEST 8 : RETOUR D''UN LIVRE (CAS NORMAL) =======
/

BEGIN
    -- Retour du livre 1
    RetournerLivre(1);
END;
/

SELECT id_Livre, Titre, Etat FROM Livre WHERE id_Livre = 1;

-- ============================================================
-- TEST 9 : Retour d'un livre déjà disponible (gestion)
-- ============================================================
PROMPT
PROMPT ======= TEST 9 : RETOUR LIVRE DÉJÀ DISPONIBLE =======
/

BEGIN
    -- Le livre 1 est déjà disponible (retourné au test précédent)
    RetournerLivre(1);
END;
/

-- ============================================================
-- TEST 10 : Retour d'un livre inexistant (gestion d'erreur)
-- ============================================================
PROMPT
PROMPT ======= TEST 10 : RETOUR LIVRE INEXISTANT (ERREUR) =======
/

BEGIN
    -- Tentative de retour d'un livre inexistant
    RetournerLivre(999);
END;
/

-- ============================================================
-- TEST 11 : Affichage final des livres disponibles
-- ============================================================
PROMPT
PROMPT ======= TEST 11 : LIVRES DISPONIBLES APRÈS TESTS =======
/

BEGIN
    AfficherLivresDisponibles;
END;
/


-- ============================================================
-- AFFICHAGE DE L'ÉTAT FINAL DE LA BASE DE DONNÉES
-- ============================================================
SET SERVEROUTPUT ON;
SET VERIFY OFF;
SET FEEDBACK OFF;
SET LINESIZE 200;
SET PAGESIZE 50;

DECLARE
    v_count_livre NUMBER;
    v_count_abonne NUMBER;
    v_count_emprunt NUMBER;
BEGIN
    -- Compter le nombre d'enregistrements
    SELECT COUNT(*) INTO v_count_livre FROM Livre;
    SELECT COUNT(*) INTO v_count_abonne FROM Abonne;
    SELECT COUNT(*) INTO v_count_emprunt FROM Emprunt;
    
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('=========================================================================');
    DBMS_OUTPUT.PUT_LINE('                    ÉTAT FINAL DE LA BASE DE DONNÉES                     ');
    DBMS_OUTPUT.PUT_LINE('=========================================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================
    -- AFFICHAGE DES LIVRES
    -- ============================================================
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('                              LISTE DES LIVRES                            ');
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 8) || RPAD('TITRE', 45) || RPAD('AUTEUR', 35) || 'ETAT');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 8, '-') || RPAD('-', 45, '-') || RPAD('-', 35, '-') || RPAD('-', 12, '-'));
    
    FOR r IN (SELECT id_Livre, Titre, Auteur, Etat FROM Livre ORDER BY id_Livre) LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(r.id_Livre, 8) || 
            RPAD(SUBSTR(r.Titre, 1, 43), 45) || 
            RPAD(SUBSTR(r.Auteur, 1, 33), 35) || 
            r.Etat
        );
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Total des livres : ' || v_count_livre);
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================
    -- AFFICHAGE DES ABONNÉS
    -- ============================================================
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('                             LISTE DES ABONNÉS                            ');
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE(RPAD('ID', 15) || RPAD('NOM', 25) || 'PRENOM');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 15, '-') || RPAD('-', 25, '-') || RPAD('-', 25, '-'));
    
    FOR r IN (SELECT id_Abonne, Nom, Prenom FROM Abonne ORDER BY id_Abonne) LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(r.id_Abonne, 15) || 
            RPAD(r.Nom, 25) || 
            r.Prenom
        );
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Total des abonnés : ' || v_count_abonne);
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================
    -- AFFICHAGE DES EMPRUNTS
    -- ============================================================
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('                             HISTORIQUE DES EMPRUNTS                      ');
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE(RPAD('ID_EMPRUNT', 12) || RPAD('TITRE LIVRE', 45) || RPAD('ABONNÉ', 35) || 'DATE EMPRUNT');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 12, '-') || RPAD('-', 45, '-') || RPAD('-', 35, '-') || RPAD('-', 15, '-'));
    
    FOR r IN (SELECT e.id_Emprunt, l.Titre, a.Nom || ' ' || a.Prenom AS Abonne, 
                     TO_CHAR(e.Date_Emprunt, 'DD/MM/YYYY') AS Date_Emprunt
              FROM Emprunt e
              JOIN Livre l ON e.id_Livre = l.id_Livre
              JOIN Abonne a ON e.id_Abonne = a.id_Abonne
              ORDER BY e.id_Emprunt) LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(r.id_Emprunt, 12) || 
            RPAD(SUBSTR(r.Titre, 1, 43), 45) || 
            RPAD(SUBSTR(r.Abonne, 1, 33), 35) || 
            r.Date_Emprunt
        );
    END LOOP;
    
    IF v_count_emprunt = 0 THEN
        DBMS_OUTPUT.PUT_LINE(RPAD(' ', 12) || 'Aucun emprunt enregistré pour le moment.');
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Total des emprunts : ' || v_count_emprunt);
    DBMS_OUTPUT.PUT_LINE('');
    
    -- ============================================================
    -- RÉSUMÉ FINAL
    -- ============================================================
    DBMS_OUTPUT.PUT_LINE('=========================================================================');
    DBMS_OUTPUT.PUT_LINE('                           RÉSUMÉ DE LA BASE                              ');
    DBMS_OUTPUT.PUT_LINE('=========================================================================');
    DBMS_OUTPUT.PUT_LINE('  - Livres :     ' || RPAD(v_count_livre, 6) || ' Livres(s)');
    DBMS_OUTPUT.PUT_LINE('  - Abonnés :    ' || RPAD(v_count_abonne, 6) || ' inscrit(s)');
    DBMS_OUTPUT.PUT_LINE('  - Emprunts :   ' || RPAD(v_count_emprunt, 6) || ' enregistré(s)');
    DBMS_OUTPUT.PUT_LINE('=========================================================================');
    
END;
/